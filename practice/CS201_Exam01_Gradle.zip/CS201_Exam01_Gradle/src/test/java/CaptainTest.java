import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CaptainTest {

	// declare references to Captains
	// kirk calls the full constructor
	// picard calls the constructor that only sets firstName and lastName
	// picard's gradYear and shipNamee will then be set separately
	private Captain kirk;
	private Captain picard;

	@Before
	// 2 Captains, one for each constructor
	public void setUp() throws Exception {
		kirk = new Captain("James", "Kirk", 2254, "USS Enterprise");
		picard = new Captain("Jean-Luc", "Picard");
	}
	
	@Test
	// 2 tests, one for each constructor
	public void testGetFirstName() throws Exception {
		assertEquals("James", kirk.getFirstName());
		assertEquals("Jean-Luc", picard.getFirstName());
	}
	
	@Test
	// 2 tests, one for each constructor	
	public void testGetLastName() throws Exception {
		assertEquals("Kirk", kirk.getLastName());
		assertEquals("Picard", picard.getLastName());
	}
	
	@Test
	// 2 tests, one for each constructor	
	public void testGetGradYear() throws Exception {
		assertEquals(2254, kirk.getGradYear());
		assertEquals(0, picard.getGradYear());
	}
	
	@Test
	// 2 tests, one for each constructor	
	public void testGetShipName() throws Exception {
		assertEquals("USS Enterprise", kirk.getShipName());
		assertEquals(null, picard.getShipName());
	}
	
	@Test
	// test that the full name method works
	public void testGetFullName() throws Exception {
		assertEquals("James Kirk", kirk.getFullName());
	}
	
	@Test
	// test that sets and the retrieves the graduation year
	public void testSetGradYear() throws Exception {
		picard.setGradYear(2327);
		assertEquals(2327, picard.getGradYear());
	}
	@Test
	// test that sets and then retrieves the ship name
	public void testSetShipName() throws Exception {
		picard.setShipName("USS Enterprise");
		assertEquals("USS Enterprise", picard.getShipName());
	}	
}
