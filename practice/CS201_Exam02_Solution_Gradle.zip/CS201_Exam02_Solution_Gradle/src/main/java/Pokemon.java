public class Pokemon implements Comparable<Pokemon> {
	private PokemonType primary;
	private PokemonType secondary;
	private String name;
	
	public Pokemon(PokemonType primary, String name) {
		this.primary = primary;
		this.secondary = PokemonType.NONE;
		this.name = name;
	}
	
	public Pokemon(PokemonType primary, PokemonType secondary, String name) {
		this.primary = primary;
		this.secondary = secondary;
		this.name = name;
	}
	
	public PokemonType getPrimaryType() { return primary; }
	
	public PokemonType getSecondaryType() { return secondary; }
	
	public String getName() {
		return name;
	}
	
	@Override
	public int compareTo(Pokemon o) {
		int cmp;
		cmp = this.primary.compareTo(o.primary);
		if (cmp != 0) return cmp;
		cmp = this.secondary.compareTo(o.secondary);
		if (cmp != 0) return cmp;
		return this.name.compareTo(o.name);
	}
}
