import java.util.Iterator;
import java.util.List;

public class Q12 {
	public static<E extends Comparable<E>> boolean isSorted(List<E> list) {
		//throw new UnsupportedOperationException("TODO - implement");
		
		if (list.isEmpty()) { return true; }

		Iterator<E> i = list.iterator();
		E prev = i.next();
		while (i.hasNext()) {
			E val = i.next();
			if (val.compareTo(prev) < 0) return false;
			prev = val;
		}
		return true;
	}
}
