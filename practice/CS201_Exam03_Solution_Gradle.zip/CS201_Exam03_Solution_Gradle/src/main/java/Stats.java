import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Stats {
	// TODO: add fields
	private Map<String, Integer> runsByPlayer;
	private Map<Integer, Integer> runsByGame;
	
	/**
	 * Constructor.
	 */
	public Stats() {
		runsByPlayer = new HashMap<String, Integer>();
		runsByGame = new HashMap<Integer, Integer>();
	}
	
	/**
	 * Record the number of runs a particular player scored
	 * in a specific game.
	 * 
	 * @param player   the player
	 * @param game     the game number
	 * @param numRuns  the number of runs scored
	 */
	public void updateStats(String player, int game, int numRuns) {
		// update runs by player
		if (!runsByPlayer.containsKey(player)) {
			runsByPlayer.put(player, numRuns);
		} else {
			int prev = runsByPlayer.get(player);
			runsByPlayer.put(player, prev + numRuns);
		}
		
		// update runs by game
		if (!runsByGame.containsKey(game)) {
			runsByGame.put(game, numRuns);
		} else {
			int prev = runsByGame.get(game);
			runsByGame.put(game, prev + numRuns);
		}
	}
	
	/**
	 * Get the number of runs a player scored over all games.
	 * 
	 * @param player the player
	 * @return the number of runs
	 */
	public int getRunsForPlayer(String player) {
		return runsByPlayer.get(player);
	}
	
	/**
	 * Get the number of runs scored in a game (by all players).
	 * 
	 * @param game the game number
	 * @return the number of runs
	 */
	public int getRunsForGame(int game) {
		return runsByGame.get(game);
	}
}
