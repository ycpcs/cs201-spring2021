public class Target {
	// TODO: declare the fields
	private Point[] arrows;
	private double score;

	// TODO: create the Target constructor that accepts an array of Points (arrow locations)
	//          and sets arrows to the array passed in.
	//       the constructor must also calculate the score for the set of arrow locations
	public Target(Point[] arrows) {
		this.arrows = arrows;
		this.score  = calcScore();
	}
	
	// getter method that returns the score
	// NOTE: it does not calculate the score, that must be done in the constructor
	public double getScore() {
		return score;
	}
	
	// getter method that returns a reference to the arrows array
	public Point[] getArrows() {
		return arrows;
	}
	
	// TODO: define a calcScore method that calculates the score for all arrows
	//       calcScore must be called from the Target constructor to set the score
	//       the score is the average distance of all arrows from the center of the target (0,0)
	//       the arrows hit the target at the Point coordinates stored in the arrows array
	private double calcScore() {
		double score = 0;
		
		for (int i = 0; i < arrows.length; i++) {
			score += Math.sqrt(arrows[i].getX() * arrows[i].getX() + arrows[i].getY() * arrows[i].getY());
		}
		
		System.out.println("Score (" + arrows.length + ") = " + score / arrows.length);
		
		return score / arrows.length;
	}
}
