/**
 * An instance of the Captain class represents
 * a Star Fleet captain
 */
public class Captain {
	// TODO: add fields.
	// You need to store information about the Captain (use the following variable names and types:
	//     firstName (String), lastName (String), gradYear (int), shipName (String)
	private String firstName;
	private String lastName;
	private int    gradYear;
	private String shipName;

	/**
	 * Constructor 1.
	 * Store firstName, lastName, in the fields
	 * of the object being initialized.
	 * Initialize gradYear to 0
	 * Initialize shipName to null
	 * 
	 * @param firstName the Captain's first name
	 * @param lastName the Captains's last name
	 */
	// TODO: add constructor that accepts first name and last name
	//       initialize gradYear to 0, and shipName to null
	public Captain(String firstName, String lastName) {
		this.firstName    = firstName;
		this.lastName     = lastName;
		this.gradYear     = 0;
		this.shipName     = null;
	}

	/**
	 * Constructor 2.
	 * Store firstName, lastName, gradYear, shipName in the fields
	 * of the object being initialized.
	 * 
	 * @param firstName the Captain's first name
	 * @param lastName the Captains's last name
	 * @param gradYear year of graduation from Star Fleet Academy
	 * @param shipName name of the Captains' ship
	 */

	// TODO: add constructor that accepts first name, last name, grad year, and ship name
	public Captain(String firstName, String lastName, int gradYear, String shipName) {
		this.firstName = firstName;
		this.lastName  = lastName;
		this.gradYear  = gradYear;
		this.shipName  = shipName;
	}	

	// TODO: add getter methods for each field in the Captain class
	//       the method names must MATCH those called in the JUNit test cases

	/**
	 * @return the Captain's first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the Captain's last name
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * @return the Captain's graduation year
	 */
	public int getGradYear() {
		return gradYear;
	}

	/**
	 * @return the Captain's ship name
	 */
	public String getShipName() {
		return shipName;
	}

	// TODO: add setter methods for shipName and gradYear
	//       the method names MUST match those called in the JUnit test cases

	/**
	 * set the name of the Captain's ship
	 * 
	 * @param shipName name of Captain's ship
	 * @return nothing
	 */
	public void setShipName(String shipName) {
		this.shipName = shipName;
	}

	/**
	 * set the graduation year of the captain
	 * 
	 * @param gradYear Captain's year of graduation from Star Fleet Academy
	 * @return nothing
	 */
	public void setGradYear(int gradYear) {
		this.gradYear = gradYear;
	}
	
	// TODO: add a method that returns the Captain's full name in the form
	//                     "firstName lastName"
	//       the method name MUST match that called in the JUnit test case
	/**
	 * @return the Captain's full name ("firstName lastName")
	 */
	public String getFullName() {
		return firstName + " " + lastName;
	}	
}
