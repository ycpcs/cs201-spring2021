public class Coins {
	// TODO: add fields here

	// TODO: add constructor
	
	// TODO: add getters
	
	// TODO: add methods
}
