public class CirclesModel {
	private static final int startR = 10;
	
	// TODO: add field to store placed Circle
	
	// TODO: add field for counter
	
	
	// constructor
	public CirclesModel() {
		// TODO: initialize fields
		
	}
	
	// TODO: getter and setter methods
	public Circle getCircle() {
		
	}
	
	public int getCount() {
		
	}
	
	public void updateCount() {
		
	}
	
	// TODO: create new Circle from outline values
	public void addCircle(int x, int y, int r) {
		
	}

}
