public enum Terrain {
	ROAD,
	AIRPORT,
	WATER,
	MARINA,
	FIELD,
	FOREST,
	MOUNTAIN;
}
