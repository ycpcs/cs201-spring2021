import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class TicTacToePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private static final int WIDTH = 300;
	private static final int HEIGHT = 300;
	private static final Font FONT = new Font("Dialog", Font.BOLD, 24);
	
	// Fields for model and controller
	private TicTacToeModel model;
	private TicTacToeController controller;
	private boolean win;
	private boolean draw;
	
	// constructor
	public TicTacToePanel() {
		// Initialize model and controller
		model = new TicTacToeModel();
		controller = new TicTacToeController();
		win = false;
		draw = false;
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.BLACK);
		
		// Register mouse listener event handler for click events
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
		
		// Register key typed event handler for typed keys
		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				
				
			}

			@Override
			public void keyPressed(KeyEvent e) {
				handleKeyTyped(e);
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}
			
		});
	}

	/**
	 * TODO: Handle mouse click events to place pieces on
	 * the board and check for win/draw conditions.
	 * 
	 * @param e the MouseEvent object
	 */
	private void handleMouseClick(MouseEvent e) {
	
	}
	
	/**
	 * TODO: Handle key typed events to save/load
	 * the current game state
	 * 
	 * @param e the KeyEvent object
	 */
	private void handleKeyTyped(KeyEvent e) {

	}
	
	/**
	 * TODO: Handle drawing the graphics window
	 * 
	 * @param g the Graphics object
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g); // paint background
		
		// draw the tic-tac-toe board
		g.setColor(Color.WHITE);
		for (int i = 1; i < 4; i++) {
			// Vertical line
			g.drawLine(i*100, 0, i*100, HEIGHT-1);
			// Horizontal line
			g.drawLine(0, i*100, WIDTH-1, i*100);
		}
				
	}
}
