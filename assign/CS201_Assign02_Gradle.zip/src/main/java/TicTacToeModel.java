import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * An instance of the TicTacToeModel class represents the
 * state of a tic-tac-toe game.
 */
public class TicTacToeModel {
	public static final int PLAYER_X = 1;
	public static final int PLAYER_O = 2;
	public static final String saveGame = "saveGame.txt";
	
	// Field for current player
	private int turn;
		
	// TODO: Add field for the board array
	
	
	/**
	 * TODO: Constructor.
	 * Initialize the board array
	 * and start with PLAYER_X.
	 * 
	 */
	public TicTacToeModel() {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * @return the model's current player's turn
	 */
	public int getTurn() {
		return turn;
	}

	/**
	 * TODO: Return current board
	 *
	 * @return the model's current board
	 */
	public int[][] getBoard() {
		throw new UnsupportedOperationException("not implemented yet");
	}
		
	/**
	 * TODO: Return true if the move is legal, false otherwise.
	 * A move is legal if the row and column are both in the
	 * range 0-2, the board is currently empty (0) at that cell,
	 * and it is the players turn.
	 * 
	 * @param player the player attempting to place a marker
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 * @return true if the move is legal, false if it is not
	 */
	public boolean isLegalMove(int player, int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Place the marker for the current player on the board.
	 * It is assumed that this method will only be called for
	 * legal moves.
	 * 
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 */
	public void placeMarker(int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * TODO: Switch the current player
	 * 
	 */
	public void updateTurn() {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Return true if the current player has three 
	 * consecutive markers either in a row, column
	 * or diagonal on the board, false otherwise
	 * 
	 * @return true if the current player has a
	 * winning configuration, false if not
	 */
	public boolean playerWins() {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * TODO: Return true if the game is a draw. A game is
	 * a draw if all the cells are non-empty. 
	 * It is assumed that this method will only be
	 * called after the win condition is checked
	 * 
	 * @return true if the game is a draw, false if not
	 */
	public boolean isDraw() {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Read a game state from the saveGame file storing it
	 * in the board.
	 * 
	 * @return true if loading is successful, false if not
	 */
	public boolean readBoard() {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Write the game state to the saveGame file.
	 * 
	 * @return true if loading is successful, false if not
	 */
	public boolean writeBoard() {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * Constructor FOR TESTING ONLY.
	 * DO NOT USE THIS CONSTRUCTOR
	 * 
	 */
	public TicTacToeModel(int[][] board, int turn) {
		this.board = board;
		this.turn = turn;
	}

}
