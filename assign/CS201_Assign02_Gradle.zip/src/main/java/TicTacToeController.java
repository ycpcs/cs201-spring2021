/**
 * An instance of the TicTacToeController class represents
 * a controller to update the state of a tic-tac-toe game
 */
public class TicTacToeController {		
	/**
	 * TODO: Check if the current attempted move is legal.
	 * 
	 * @param model the current game model
	 * @param player the player attempting to place a marker
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 * @return true if the move is legal, false if it is not
	 */
	public boolean checkMove(TicTacToeModel model, int player, int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Check if the current move results in a winning
	 * configuration.
	 * 
	 * @param model the current game model
	 * @return true if the current player wins, false if not
	 */
	public boolean checkWin(TicTacToeModel model){
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Check if the current move results in a draw
	 * configuration.
	 * 
	 * @param model the current game model
	 * @return true if there is a draw, false if not
	 */
	public boolean checkDraw(TicTacToeModel model) {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * TODO: Update the board with the current players marker.
	 * It is assumed the current move is legal.
	 * 
	 * @param model the current game model
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 */
	public void updateBoard(TicTacToeModel model, int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * TODO: Switch the current player's turn.
	 * 
	 * @param model the current game model
	 */
	public void changePlayer(TicTacToeModel model) {
		throw new UnsupportedOperationException("not implemented yet");
	}
}
