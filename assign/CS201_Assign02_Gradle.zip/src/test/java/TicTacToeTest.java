import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class TicTacToeTest {
	private static int[][] EMPTY_BOARD = {
			{ 0, 0, 0 },
			{ 0, 0, 0 },
			{ 0, 0, 0 },
	};
	private static int[][] CENTER_X_BOARD = {
			{ 0, 0, 0 },
			{ 0, TicTacToeModel.PLAYER_X, 0 },
			{ 0, 0, 0 },
	};
	private static int[][] X_WINS_ROW_BOARD = {
			{ 0, TicTacToeModel.PLAYER_O, TicTacToeModel.PLAYER_O },
			{ TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_X },
			{ TicTacToeModel.PLAYER_O, 0, 0 },
	};
	private static int[][] DRAW_BOARD = {
			{ TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_O, TicTacToeModel.PLAYER_X },
			{ TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_O },
			{ TicTacToeModel.PLAYER_O, TicTacToeModel.PLAYER_X, TicTacToeModel.PLAYER_O },
	};
	
	private int[][] transpose(int[][] a) {
		int[][] result = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				result[j][i] = a[i][j];
			}
		}
		return result;
	}
	
	private int[][] invertPlayer(int[][] a) {
		int[][] result = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				int p = a[i][j];
				if (p != 0) {
					p = (p == TicTacToeModel.PLAYER_X) ? TicTacToeModel.PLAYER_O : TicTacToeModel.PLAYER_X;
				}
				result[i][j] = p;
			}
		}
		return result;
	}

	private TicTacToeModel emptyBoard;
	private TicTacToeModel centerX;
	private TicTacToeModel xWinsRow;
	private TicTacToeModel xWinsCol;
	private TicTacToeModel oWinsRow;
	private TicTacToeModel oWinsCol;
	private TicTacToeModel draw;
	
	@Before
	public void setUp() {
		emptyBoard = new TicTacToeModel(EMPTY_BOARD, TicTacToeModel.PLAYER_X);
		centerX = new TicTacToeModel(CENTER_X_BOARD.clone(), TicTacToeModel.PLAYER_O);
		xWinsRow = new TicTacToeModel(X_WINS_ROW_BOARD.clone(), TicTacToeModel.PLAYER_X);
		xWinsCol = new TicTacToeModel(transpose(X_WINS_ROW_BOARD), TicTacToeModel.PLAYER_X);
		oWinsRow = new TicTacToeModel(invertPlayer(X_WINS_ROW_BOARD), TicTacToeModel.PLAYER_O);
		oWinsCol = new TicTacToeModel(transpose(invertPlayer(X_WINS_ROW_BOARD)), TicTacToeModel.PLAYER_O);
		draw = new TicTacToeModel(DRAW_BOARD.clone(), TicTacToeModel.PLAYER_O);
	}
	
	@Test
	public void testgetBoard() {
		assertTrue(Arrays.equals(emptyBoard.getBoard(), EMPTY_BOARD));
		assertTrue(Arrays.equals(centerX.getBoard(),CENTER_X_BOARD));
		assertTrue(Arrays.equals(xWinsRow.getBoard(),X_WINS_ROW_BOARD));
		assertFalse(Arrays.equals(oWinsRow.getBoard(),X_WINS_ROW_BOARD));
	}
	
	@Test
	public void testIsLegalMove() {
		assertTrue(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 0, 0));
		assertTrue(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 2, 0));
		assertTrue(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 0, 2));
		assertFalse(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 4, 0));
		assertFalse(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 0, 4));
		assertFalse(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, -1, 1));
		assertFalse(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_X, 2, -5));
		assertFalse(emptyBoard.isLegalMove(TicTacToeModel.PLAYER_O, 0, 2));
		
		assertTrue(centerX.isLegalMove(TicTacToeModel.PLAYER_O, 0, 2));
		assertFalse(centerX.isLegalMove(TicTacToeModel.PLAYER_O, 1, 1));
		assertFalse(centerX.isLegalMove(TicTacToeModel.PLAYER_X, 1, 2));
	}

	@Test
	public void testPlaceMarker() {
		emptyBoard.placeMarker(2, 1);
		assertEquals(emptyBoard.getBoard()[2][1],TicTacToeModel.PLAYER_X);
		centerX.placeMarker(0, 2);
		assertEquals(centerX.getBoard()[0][2],TicTacToeModel.PLAYER_O);
	}
	
	@Test
	public void testUpdateTurn() {
		assertEquals(emptyBoard.getTurn(),TicTacToeModel.PLAYER_X);
		emptyBoard.placeMarker(2, 1);
		emptyBoard.updateTurn();
		assertEquals(emptyBoard.getTurn(),TicTacToeModel.PLAYER_O);
		assertEquals(centerX.getTurn(),TicTacToeModel.PLAYER_O);
		centerX.placeMarker(0, 2);
		centerX.updateTurn();
		assertEquals(centerX.getTurn(),TicTacToeModel.PLAYER_X);
	}


	@Test
	public void testPlayerWins() {
		assertTrue(xWinsRow.playerWins());
		assertTrue(xWinsCol.playerWins());
		assertFalse(emptyBoard.playerWins());
		assertFalse(centerX.playerWins());

		assertTrue(oWinsRow.playerWins());
		assertTrue(oWinsCol.playerWins());
	}
	
	@Test
	public void testIsDraw() {
		assertFalse(emptyBoard.isDraw());
		assertFalse(centerX.isDraw());
		assertTrue(draw.isDraw());
	}
	
}
