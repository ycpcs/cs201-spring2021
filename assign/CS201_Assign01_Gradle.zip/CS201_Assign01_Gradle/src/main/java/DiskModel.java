import java.util.ArrayList;

/**
 * The model for the disk game
 * which stores and ArrayList of Disks
 */
public class DiskModel {
	// TODO: add fields.

	/**
	 * Constructor.
	 * Creates empty ArrayList
	 */
	public DiskModel() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the ArrayList of Disks
	 */
	public ArrayList<Disk> getDisks() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the number of placed disks
	 */
	public int getNumDisks() {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
