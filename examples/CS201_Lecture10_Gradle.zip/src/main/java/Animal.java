public interface Animal {
  public int numberOfLegs();
  public void makeSound();
}
