import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ArrayListApp {
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		ArrayList names = new ArrayList();
		
		System.out.println("Type some names:");
		while(true) {
    		String name = reader.readLine();
    		if (name.equals("")) {
        		break;
    		}
    		names.add(name);
		}

		int count = countStringsContaining(names, 'J') +
    				countStringsContaining(names, 'j');

		System.out.println("You entered "+ count + " names containing J");
		
		//ArrayList deck = new ArrayList();
		//deck.add(new Card(Suit.DIAMONDS, Rank.QUEEN));
		//deck.add(new Card(Suit.SPADES, Rank.TWO));

		//int count2 = countStringsContaining(deck, 'J'); // (!)
	}

	public static int countStringsContaining(ArrayList strings, char ch) {
    	int count = 0;

    	for (int i = 0; i < strings.size(); i++) {
        	String s = (String) strings.get(i); // (!)
        	if (s.indexOf(ch) >= 0) {
            	count++;
       		 }
    	}

    	return count;
	}
}